def afficher_bienvenue():
    print("*" * 140)
    print("*" + " " * 38 + "*")
    print("*" + " " * 50 + "Bienvenue sur notre site avec python!" + " " * 50 + "*")
    print("*" + " " * 38 + "*")
    print("*" * 140)

afficher_bienvenue()
 